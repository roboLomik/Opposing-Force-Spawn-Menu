Xash3d Half-Life Opposing Force npc Spawn Menu.

Russian

1. Распаковать файлы в папку "xash".

2. Переместить: Config.cfg; Spawner.cfg; Spawner1.cfg; Spawner2.cfg; Spawner3.cfg в папку "gearbox".

3. Создать кнопку в "touch buttons" с командой "exec Spawner".

                                        Готово!
English 

1. Unzip files to "xash" folder. 

2. Move: Config.cfg Spawner.cfg; Spawner1.cfg; Spawner2.cfg Spawner3.cfg to the "gearbox" folder.

3. Create a button in "touch buttons" with command "exec Spawner".

                                        Ready!


2023.roboLomik